﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace MedicalMngSysem
{
    public partial class Bill : UserControl
    {
        public Bill()
        {
            InitializeComponent();
        }
        public void ClearAllData()
        {
            clearDataOfAddToCard();
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            txtName.Text = "";
            txtAddress.Text = "";
            txtmobno.Text = "";
            txtTotal.Text = "0";
        }
        public void clearDataOfAddToCard()
        {
            dataGridView1.Refresh();
            cbPData.Text = "";
            lblsrno.Text = "";
            lblexdate.Text = "";
            lblrate.Text = "";
            txtqty.Text = "";
           // txtTotal.Text = "";

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
            SqlConnection con = new SqlConnection(constring);
            //DataTable donater = new DataTable();
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from tbl_Stock where mname='" + cbPData.Text + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                lblsrno.Text = dr["srno"].ToString();
                lblexdate.Text = dr["exdate"].ToString();
                lblrate.Text = dr["rate"].ToString();

            }
            con.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        private void btnRefersh_Click(object sender, EventArgs e)
        {
            try
            {
                cbPData.Items.Clear();
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
                //DataTable donater = new DataTable();
                con.Open();
                SqlCommand cmd = new SqlCommand("select mname from tbl_Stock ", con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cbPData.Items.Add(dr[0].ToString());
                }
                cbPData.AutoCompleteMode = AutoCompleteMode.Suggest;
                cbPData.AutoCompleteSource = AutoCompleteSource.ListItems;

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        int cnt = 0;
        private void btnAddtoCard_Click(object sender, EventArgs e)
        {
            cnt++;
            int n = dataGridView1.Rows.Add();
            dataGridView1.Rows[n].Cells[0].Value = cnt.ToString();
            dataGridView1.Rows[n].Cells[1].Value = cbPData.Text;
            dataGridView1.Rows[n].Cells[2].Value = lblsrno.Text;
            dataGridView1.Rows[n].Cells[3].Value = lblrate.Text;
            dataGridView1.Rows[n].Cells[4].Value = txtqty.Text;
           // dataGridView1.Rows[n].Cells[5].Value = txtRate.Text;
           double  rate = double.Parse(lblrate.Text);
          double  qty = double.Parse(txtqty.Text);
           double temp = qty * rate;

            dataGridView1.Rows[n].Cells[5].Value = temp.ToString();
          double  total = double.Parse(txtTotal.Text);

            total = total + temp;
            txtTotal.Text = total.ToString();

            clearDataOfAddToCard();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cbPData.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            lblsrno.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            lblrate.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtqty.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            //txtRate.Text = dataGridViewAddToCard.Rows[e.RowIndex].Cells[5].Value.ToString();
        }
        private int rowIndex = 0;
        private void dataGridView1_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {

                this.dataGridView1.Rows[e.RowIndex].Selected = true;

                this.rowIndex = e.RowIndex;

                this.dataGridView1.CurrentCell = this.dataGridView1.Rows[e.RowIndex].Cells[1];

                this.contextMenuStrip1.Show(this.dataGridView1, e.Location);

                contextMenuStrip1.Show(Cursor.Position);

            }
        }

        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            if (!this.dataGridView1.Rows[this.rowIndex].IsNewRow)
            {
                cnt--;

                double p, q, temp, total;
                p = double.Parse(lblrate.Text);
                q = double.Parse(txtqty.Text);
                temp = p * q;
                total = Convert.ToDouble(txtTotal.Text);
                total = total - temp;
                txtTotal.Text = total.ToString();

            }
            this.dataGridView1.Rows.RemoveAt(this.rowIndex);
            clearDataOfAddToCard();
        }

        private void btnNewEntry_Click(object sender, EventArgs e)
        {
            ClearAllData();
        }
        int lastid;
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {

                string srno, pname, sno, rate, amt, gwt,qty,stot;
               
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);

                con.Open();

                SqlCommand cmd = new SqlCommand("insert into Sale(total)values(@total) select @@identity;", con);

                cmd.Parameters.AddWithValue("@total", txtTotal.Text);
                lastid = int.Parse(cmd.ExecuteScalar().ToString());

                for (int row = 0; row < dataGridView1.Rows.Count - 1; row++)
                {
                    sno = dataGridView1.Rows[row].Cells[0].Value.ToString();
                    pname = dataGridView1.Rows[row].Cells[1].Value.ToString();
                    srno = dataGridView1.Rows[row].Cells[2].Value.ToString();
                    rate = dataGridView1.Rows[row].Cells[3].Value.ToString();
                   // qty =double.Parse( dataGridView1.Rows[row].Cells[4].Value.ToString());
                    qty = dataGridView1.Rows[row].Cells[4].Value.ToString();
                    stot = dataGridView1.Rows[row].Cells[5].Value.ToString();
                    SqlCommand cmd1 = new SqlCommand("insert into Sale_Product(bid,date,name,address,mobno,sno,pname,srno,rate,qty,stotal,ftotal)values(@bid,@date,@name,@address,@mobno,@sno,@pname,@srno,@rate,@qty,@stotal,@ftotal)", con);
                    cmd1.Parameters.AddWithValue("@bid", lastid);
                    cmd1.Parameters.AddWithValue("@date", DateTime.Now.ToString("yyyy-MM-dd"));
                    cmd1.Parameters.AddWithValue("@name", txtName.Text);
                    cmd1.Parameters.AddWithValue("@address", txtAddress.Text);
                    cmd1.Parameters.AddWithValue("@mobno", txtmobno.Text);
                    cmd1.Parameters.AddWithValue("@sno", sno);
                    cmd1.Parameters.AddWithValue("@pname", pname);
                    cmd1.Parameters.AddWithValue("@srno", srno);
                  
                    cmd1.Parameters.AddWithValue("@rate", rate);
                    cmd1.Parameters.AddWithValue("@qty", qty);
                    cmd1.Parameters.AddWithValue("@stotal", stot);
                    cmd1.Parameters.AddWithValue("@ftotal", txtTotal.Text);
                    cmd1.ExecuteNonQuery();
                }


              

                MessageBox.Show("Record inserted");

               // bid++;

                con.Close();
                SaleID = lastid;
                PrintBill ob = new PrintBill();
                ob.Show();
            }



            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            
            ClearAllData();
            clearDataOfAddToCard();
        }
        public static int SaleID;
    }
}
